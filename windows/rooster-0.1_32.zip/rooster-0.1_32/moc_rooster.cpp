/****************************************************************************
** Meta object code from reading C++ file 'rooster.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../rooster-0.1/rooster.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rooster.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_rooster_t {
    QByteArrayData data[10];
    char stringdata[151];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_rooster_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_rooster_t qt_meta_stringdata_rooster = {
    {
QT_MOC_LITERAL(0, 0, 7),
QT_MOC_LITERAL(1, 8, 22),
QT_MOC_LITERAL(2, 31, 0),
QT_MOC_LITERAL(3, 32, 36),
QT_MOC_LITERAL(4, 69, 12),
QT_MOC_LITERAL(5, 82, 6),
QT_MOC_LITERAL(6, 89, 26),
QT_MOC_LITERAL(7, 116, 4),
QT_MOC_LITERAL(8, 121, 23),
QT_MOC_LITERAL(9, 145, 4)
    },
    "rooster\0on_alarmButton_clicked\0\0"
    "on_actionChoose_Audio_File_triggered\0"
    "checktraffic\0fadein\0on_arrivaltime_timeChanged\0"
    "time\0on_pretime_valueChanged\0arg1\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_rooster[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   44,    2, 0x08,
       3,    0,   45,    2, 0x08,
       4,    0,   46,    2, 0x08,
       5,    0,   47,    2, 0x08,
       6,    1,   48,    2, 0x08,
       8,    1,   51,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QTime,    7,
    QMetaType::Void, QMetaType::Int,    9,

       0        // eod
};

void rooster::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        rooster *_t = static_cast<rooster *>(_o);
        switch (_id) {
        case 0: _t->on_alarmButton_clicked(); break;
        case 1: _t->on_actionChoose_Audio_File_triggered(); break;
        case 2: _t->checktraffic(); break;
        case 3: _t->fadein(); break;
        case 4: _t->on_arrivaltime_timeChanged((*reinterpret_cast< const QTime(*)>(_a[1]))); break;
        case 5: _t->on_pretime_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject rooster::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_rooster.data,
      qt_meta_data_rooster,  qt_static_metacall, 0, 0}
};


const QMetaObject *rooster::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *rooster::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_rooster.stringdata))
        return static_cast<void*>(const_cast< rooster*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int rooster::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}
struct qt_meta_stringdata_phantomio_t {
    QByteArrayData data[5];
    char stringdata[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_phantomio_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_phantomio_t qt_meta_stringdata_phantomio = {
    {
QT_MOC_LITERAL(0, 0, 9),
QT_MOC_LITERAL(1, 10, 14),
QT_MOC_LITERAL(2, 25, 0),
QT_MOC_LITERAL(3, 26, 3),
QT_MOC_LITERAL(4, 30, 4)
    },
    "phantomio\0getTransitTime\0\0com\0args\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_phantomio[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   19,    2, 0x0a,

 // slots: parameters
    QMetaType::QString, QMetaType::QString, QMetaType::QStringList,    3,    4,

       0        // eod
};

void phantomio::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        phantomio *_t = static_cast<phantomio *>(_o);
        switch (_id) {
        case 0: { QString _r = _t->getTransitTime((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject phantomio::staticMetaObject = {
    { &QProcess::staticMetaObject, qt_meta_stringdata_phantomio.data,
      qt_meta_data_phantomio,  qt_static_metacall, 0, 0}
};


const QMetaObject *phantomio::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *phantomio::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_phantomio.stringdata))
        return static_cast<void*>(const_cast< phantomio*>(this));
    return QProcess::qt_metacast(_clname);
}

int phantomio::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QProcess::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
